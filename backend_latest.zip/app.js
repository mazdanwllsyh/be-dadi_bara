console.log(
  "--- SERVER BERJALAN DI Waktu " + new Date().toLocaleTimeString() + " ---"
);
console.log(`SERVER STARTUP - NODE_ENV: [${process.env.NODE_ENV}]`);

import express from "express";
import mongoose from "mongoose";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import mongoSanitize from "express-mongo-sanitize";
import helmet from "helmet";
import path from "path";
import { fileURLToPath } from "url";
import { MulterError } from "multer";

// ... ROUTER ...
import userRouter from "./routers/userRouter.js";
import testimonialRoutes from "./routers/testimonialRouter.js";
import { errorHandler, notFound } from "./middlewares/errorMiddleware.js";
import landingConfigRoutes from "./routers/landingConfigRoutes.js";
import jadwalKegiatanRoutes from "./routers/jadwalKegiatanRoutes.js";
import faqRoutes from "./routers/faqRoutes.js";
import galleryRouter from "./routers/galleryRouter.js";
import keuanganRouter from "./routers/keuanganRouter.js";
import memberRoutes from "./routers/memberRoute.js";
import skRouter from "./routers/skRouter.js";
import pendaftaranRouter from "./routers/pendaftaranRouter.js";
import notulensiRoutes from "./routers/notulensiRoutes.js";
import presensiRoutes from "./routers/presensiRoutes.js";
import { v2 as cloudinary } from "cloudinary";

dotenv.config();

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const app = express();
const port = process.env.PORT || 5000;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

app.use(
  helmet({
    crossOriginResourcePolicy: false,
    contentSecurityPolicy: {
      directives: {
        ...helmet.contentSecurityPolicy.getDefaultDirectives(),
        "connect-src": ["'self'", "https://accounts.google.com"],
        "script-src": ["'self'", "https://accounts.google.com/gsi/client"],
        "img-src": [
          "'self'",
          "data:",
          "https:",
          "lh3.googleusercontent.com",
          "res.cloudinary.com",
        ],
        "frame-src": ["'self'", "https://accounts.google.com"],
      },
    },
  })
);

const allowedOrigins = [
  "http://localhost:5173",
  "http://localhost:3000",
  "https://dadibara.bejalen.com",
];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || allowedOrigins.indexOf(origin) !== -1) {
        callback(null, true);
      } else {
        callback(new Error("Asal (Origin) ini tidak diizinkan oleh CORS"));
      }
    },
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
    credentials: true,
  })
);

app.use((req, res, next) => {
  if (req.body) mongoSanitize.sanitize(req.body);
  if (req.params) mongoSanitize.sanitize(req.params);
  if (req.query) mongoSanitize.sanitize(Object.assign({}, req.query));
  next();
});

// Routes API
app.use("/api/auth", userRouter);
app.use("/api/testimonials", testimonialRoutes);
app.use("/api/landing-config", landingConfigRoutes);
app.use("/api/jadwal-kegiatan", jadwalKegiatanRoutes);
app.use("/api/faq", faqRoutes);
app.use("/api/gallery", galleryRouter);
app.use("/api/keuangan", keuanganRouter);
app.use("/api/members", memberRoutes);
app.use("/api/sk", skRouter);
app.use("/api/notulensi", notulensiRoutes);
app.use("/api/presensi", presensiRoutes);
app.use("/api/pendaftaran", pendaftaranRouter);

if (process.env.NODE_ENV === "production") {
  const __dirname = path.resolve();
  app.use(express.static(path.join(__dirname, "frontend/dist")));

  app.get("*", (req, res) =>
    res.sendFile(path.resolve(__dirname, "frontend", "dist", "index.html"))
  );
} else {
  app.get("/", (req, res) => {
    res.send("API is running....");
  });
}

app.use((err, req, res, next) => {
  if (err instanceof MulterError) {
    if (err.code === "LIMIT_FILE_SIZE") {
      return res
        .status(400)
        .json({ message: "Ukuran file terlalu besar, pastikan Maks. 6MB!" });
    }
  }
  next(err);
});
app.use(notFound);
app.use(errorHandler);

app.listen(port, () => {});

mongoose
  .connect(process.env.DATABASE, {})
  .then(() => console.log("Terhubung Database"))
  .catch((err) => console.error("Koneksi Database GAGAL:", err));
